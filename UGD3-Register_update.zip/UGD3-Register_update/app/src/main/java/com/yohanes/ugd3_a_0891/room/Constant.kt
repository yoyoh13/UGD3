package com.yohanes.ugd3_a_0891.room

class Constant {
    companion object{
        const val TYPE_READ = 0
        const val TYPE_CREATE = 1
        const val TYPE_UPDATE = 2
    }
}