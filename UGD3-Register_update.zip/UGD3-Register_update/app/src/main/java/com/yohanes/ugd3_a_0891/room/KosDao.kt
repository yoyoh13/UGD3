package com.yohanes.ugd3_a_0891.room

import androidx.room.*

@Dao
interface KosDao {

    @Insert
    fun addMemberGym(note: Kos)

    @Update
    fun updateMemberGym(note: Kos)

    @Delete
    fun deleteMemberGym(note: Kos)

    @Query("SELECT * FROM kos")
    suspend fun getMemberGym() : List<Kos>

    @Query("SELECT * FROM kos WHERE id =:user_id")
    suspend fun getMemberGym(user_id: Int) : List<Kos>
}